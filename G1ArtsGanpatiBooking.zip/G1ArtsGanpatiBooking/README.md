# G-1 Arts Ganpati Booking App

पूर्ण Android Application — गणपती मूर्ती Booking Management साठी.

## दुकान माहिती
- दुकान: G-1 Arts
- मालक: Jeevan Maruti Kubhar
- पत्ता: 136, Somvar Peth, Kumbharwada, Karad – 415110

## Tech Stack
- Kotlin + Jetpack Compose (Material 3)
- Room Database (offline local storage — app बंद केल्यावरही data सुरक्षित राहतो)
- Navigation-Compose
- MVVM Architecture (Repository + ViewModel)

## Android Studio मध्ये कसे उघडावे
1. Android Studio उघडा (Koala/Ladybug किंवा नवीन version शिफारसीय).
2. **File → Open** करून हा `G1ArtsGanpatiBooking` folder निवडा.
3. Gradle sync आपोआप सुरू होईल (पहिल्यांदा Internet लागेल — dependencies download साठी).
4. Sync पूर्ण झाल्यावर वरती **Run ▶** बटण दाबून phone/emulator वर app चालवा.
5. Menu: **Build → Build Bundle(s) / APK(s) → Build APK(s)** वापरून APK तयार करा
   (`app/build/outputs/apk/debug/app-debug.apk`).

> टीप: प्रोजेक्टमध्ये Gradle wrapper jar समाविष्ट नाही (binary file). Android Studio
> उघडताना ते आपोआप वापरेल किंवा तुम्हाला "Gradle wrapper regenerate करायचा का" असे विचारेल —
> "OK"/"Use Gradle from wrapper" निवडा, ते आपोआप डाउनलोड होईल.

## पहिल्यांदा वापरताना
- App उघडल्यावर Splash Screen नंतर तुम्हाला **Admin PIN सेट करायला** सांगितले जाईल
  (4-6 अंकी). हाच PIN पुढे प्रत्येक वेळी Login साठी लागेल.
- PIN शिवाय कोणीही Booking Delete किंवा Amount Modify करू शकत नाही.

## Features
- नवीन Booking तयार करणे (Customer, Murti, Price, Advance सह)
- Booking List + Search (नाव किंवा Mobile Number ने)
- Booking Detail — Status बदलणे, Payment History, नवीन Payment Add करणे
  (Pending Amount आपोआप calculate होते: Total − एकूण Paid)
- Delete करताना confirmation: "ही Booking कायमची Delete करायची आहे का?"
- SMS पाठवा — default SMS app मध्ये पूर्ण formatted Marathi message सह उघडते
- WhatsApp पाठवा — WhatsApp मध्ये (किंवा wa.me द्वारे browser मध्ये) formatted message सह उघडते
- Dashboard — Total/Pending/Confirmed/Completed/Cancelled Bookings, Total/Paid/Pending Amount
- सर्व data स्थानिक Room Database मध्ये साठवले जाते — Internet शिवायही पूर्ण काम करते

## Project Structure
```
app/src/main/java/com/g1arts/ganpatibooking/
├── data/          Room entities, DAO, Database, Repository
├── util/          Admin PIN auth, Date/Price formatting, SMS/WhatsApp message builders
├── viewmodel/      BookingViewModel (state + business logic)
└── ui/
    ├── theme/      Ganpati theme (Kesari/Red/Golden/Cream colors)
    ├── navigation/ Routes
    ├── screens/    Splash, AdminLogin, Dashboard, BookingList, AddEditBooking, BookingDetail
    └── components/ SummaryCard, StatusChip, BookingListItem, ConfirmDialog
```
