package com.g1arts.ganpatibooking.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Kesari,
    onPrimary = Color.White,
    primaryContainer = GoldenLight,
    onPrimaryContainer = TextDark,
    secondary = GanpatiRed,
    onSecondary = Color.White,
    tertiary = Golden,
    onTertiary = Color.White,
    background = CreamBackground,
    surface = CardWhite,
    onBackground = TextDark,
    onSurface = TextDark
)

private val DarkColors = darkColorScheme(
    primary = Kesari,
    secondary = GanpatiRed,
    tertiary = Golden
)

@Composable
fun G1ArtsGanpatiBookingTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colors,
        typography = Typography(),
        content = content
    )
}
