package com.g1arts.ganpatibooking.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.g1arts.ganpatibooking.data.BookingStatus
import com.g1arts.ganpatibooking.data.BookingWithPayments
import com.g1arts.ganpatibooking.util.DateUtils

@Composable
fun BookingListItem(
    item: BookingWithPayments,
    onClick: () -> Unit
) {
    val status = BookingStatus.fromName(item.booking.status)
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = item.booking.customerName,
                    fontWeight = FontWeight.Bold,
                    fontSize = MaterialTheme.typography.titleMedium.fontSize
                )
                StatusChip(status)
            }
            Text(text = "मूर्ती: ${item.booking.murtiName}", modifier = Modifier.padding(top = 2.dp))
            Text(text = "मो.: ${item.booking.mobileNumber}")
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "एकूण: ${DateUtils.formatPrice(item.booking.totalPrice)}")
                Text(text = "Pending: ${DateUtils.formatPrice(item.pendingAmount)}")
            }
            Text(
                text = "Booking Date: ${DateUtils.formatDate(item.booking.bookingDate)}",
                fontSize = MaterialTheme.typography.bodySmall.fontSize,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}
