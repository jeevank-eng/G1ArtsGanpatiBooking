package com.g1arts.ganpatibooking.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object DateUtils {
    private fun displayFormat() = SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH)

    fun formatDate(millis: Long): String = displayFormat().format(Date(millis))

    fun formatDateTime(millis: Long): String =
        SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.ENGLISH).format(Date(millis))

    fun formatPrice(amount: Double): String {
        return if (amount == amount.toLong().toDouble()) {
            "\u20B9${amount.toLong()}"
        } else {
            "\u20B9%.2f".format(amount)
        }
    }
}
