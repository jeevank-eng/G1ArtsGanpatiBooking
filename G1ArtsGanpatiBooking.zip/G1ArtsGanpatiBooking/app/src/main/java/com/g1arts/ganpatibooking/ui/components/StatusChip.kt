package com.g1arts.ganpatibooking.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.g1arts.ganpatibooking.data.BookingStatus
import com.g1arts.ganpatibooking.ui.theme.DangerRed
import com.g1arts.ganpatibooking.ui.theme.InfoBlue
import com.g1arts.ganpatibooking.ui.theme.SuccessGreen
import com.g1arts.ganpatibooking.ui.theme.WarningAmber

fun statusColor(status: BookingStatus): Color = when (status) {
    BookingStatus.PENDING -> WarningAmber
    BookingStatus.CONFIRMED -> InfoBlue
    BookingStatus.COMPLETED -> SuccessGreen
    BookingStatus.CANCELLED -> DangerRed
}

@Composable
fun StatusChip(status: BookingStatus, modifier: Modifier = Modifier) {
    val color = statusColor(status)
    Text(
        text = status.marathiLabel,
        color = Color.White,
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = modifier
            .background(color, RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    )
}
