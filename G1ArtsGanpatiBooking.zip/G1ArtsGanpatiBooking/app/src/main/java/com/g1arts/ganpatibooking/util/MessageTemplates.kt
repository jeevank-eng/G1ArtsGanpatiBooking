package com.g1arts.ganpatibooking.util

import com.g1arts.ganpatibooking.data.Booking

object MessageTemplates {

    private const val SHOP_NAME = "G-1 Arts"
    private const val OWNER_NAME = "Jeevan Maruti Kubhar"
    private const val SHOP_ADDRESS = "136, Somvar Peth, Kumbharwada, Karad \u2013 415110"

    fun buildSmsMessage(booking: Booking, paidAmount: Double, pendingAmount: Double): String {
        return """
            🙏 श्री गणेशाय नमः 🙏

            $SHOP_NAME तर्फे आपले हार्दिक स्वागत!

            गणपती मूर्ती Booking केल्याबद्दल धन्यवाद.

            मूर्ती: ${booking.murtiName}
            एकूण किंमत: ${DateUtils.formatPrice(booking.totalPrice)}
            Advance/Paid: ${DateUtils.formatPrice(paidAmount)}
            Pending: ${DateUtils.formatPrice(pendingAmount)}
            Booking Date: ${DateUtils.formatDate(booking.bookingDate)}

            $OWNER_NAME
            $SHOP_ADDRESS

            🙏 गणपती बाप्पा मोरया! 🙏
        """.trimIndent()
    }

    fun buildWhatsAppMessage(
        booking: Booking,
        paidAmount: Double,
        pendingAmount: Double,
        statusLabel: String
    ): String {
        return """
            🙏 श्री गणेशाय नमः 🙏
            *$SHOP_NAME*

            ग्राहकाचे नाव: ${booking.customerName}
            मूर्ती: ${booking.murtiName}
            एकूण किंमत: ${DateUtils.formatPrice(booking.totalPrice)}
            Advance/Paid: ${DateUtils.formatPrice(paidAmount)}
            Pending: ${DateUtils.formatPrice(pendingAmount)}
            Booking Date: ${DateUtils.formatDate(booking.bookingDate)}
            Status: $statusLabel

            $OWNER_NAME
            $SHOP_ADDRESS

            🙏 गणपती बाप्पा मोरया! 🙏
        """.trimIndent()
    }
}
