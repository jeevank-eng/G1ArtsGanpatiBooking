package com.g1arts.ganpatibooking.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface BookingDao {
    @Insert
    suspend fun insertBooking(booking: Booking): Long

    @Update
    suspend fun updateBooking(booking: Booking)

    @Delete
    suspend fun deleteBooking(booking: Booking)

    @Transaction
    @Query("SELECT * FROM bookings ORDER BY createdAt DESC")
    fun getAllBookingsWithPayments(): Flow<List<BookingWithPayments>>

    @Transaction
    @Query("SELECT * FROM bookings WHERE id = :id LIMIT 1")
    fun getBookingWithPayments(id: Long): Flow<BookingWithPayments?>

    @Transaction
    @Query(
        """
        SELECT * FROM bookings 
        WHERE customerName LIKE '%' || :query || '%' 
           OR mobileNumber LIKE '%' || :query || '%'
        ORDER BY createdAt DESC
        """
    )
    fun searchBookings(query: String): Flow<List<BookingWithPayments>>
}
