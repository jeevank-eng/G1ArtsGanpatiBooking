package com.g1arts.ganpatibooking.data

import androidx.room.Embedded
import androidx.room.Relation

data class BookingWithPayments(
    @Embedded val booking: Booking,
    @Relation(parentColumn = "id", entityColumn = "bookingId")
    val payments: List<Payment>
) {
    val paidAmount: Double get() = payments.sumOf { it.amount }
    val pendingAmount: Double get() = booking.totalPrice - paidAmount
}
