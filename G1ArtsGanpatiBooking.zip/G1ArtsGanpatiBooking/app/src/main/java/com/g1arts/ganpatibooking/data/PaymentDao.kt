package com.g1arts.ganpatibooking.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PaymentDao {
    @Insert
    suspend fun insertPayment(payment: Payment): Long

    @Query("SELECT * FROM payments WHERE bookingId = :bookingId ORDER BY date DESC")
    fun getPaymentsForBooking(bookingId: Long): Flow<List<Payment>>
}
