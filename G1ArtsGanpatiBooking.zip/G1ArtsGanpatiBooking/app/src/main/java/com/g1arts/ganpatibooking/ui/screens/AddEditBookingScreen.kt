package com.g1arts.ganpatibooking.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.g1arts.ganpatibooking.data.Booking
import com.g1arts.ganpatibooking.ui.theme.DangerRed
import com.g1arts.ganpatibooking.ui.theme.Kesari
import com.g1arts.ganpatibooking.util.DateUtils
import com.g1arts.ganpatibooking.viewmodel.BookingViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditBookingScreen(
    viewModel: BookingViewModel,
    bookingId: Long?,
    onBack: () -> Unit,
    onSaved: (Long) -> Unit
) {
    val isEdit = bookingId != null
    val existing = if (isEdit) {
        val flow = remember(bookingId) { viewModel.getBookingFlow(bookingId!!) }
        flow.collectAsState(initial = null).value
    } else null

    var customerName by remember(existing) { mutableStateOf(existing?.booking?.customerName ?: "") }
    var mobileNumber by remember(existing) { mutableStateOf(existing?.booking?.mobileNumber ?: "") }
    var address by remember(existing) { mutableStateOf(existing?.booking?.address ?: "") }
    var murtiName by remember(existing) { mutableStateOf(existing?.booking?.murtiName ?: "") }
    var totalPrice by remember(existing) { mutableStateOf(existing?.booking?.totalPrice?.let { if (it == 0.0) "" else it.toString() } ?: "") }
    var advanceAmount by remember(existing) { mutableStateOf("") }
    var notes by remember(existing) { mutableStateOf(existing?.booking?.notes ?: "") }
    var bookingDateMillis by remember(existing) {
        mutableStateOf(existing?.booking?.bookingDate ?: System.currentTimeMillis())
    }
    var showDatePicker by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    if (isEdit && existing == null) {
        // still loading, avoid flashing an empty form
        return
    }

    if (showDatePicker) {
        val datePickerState = rememberDatePickerState(initialSelectedDateMillis = bookingDateMillis)
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    datePickerState.selectedDateMillis?.let { bookingDateMillis = it }
                    showDatePicker = false
                }) { Text("ठीक आहे") }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) { Text("रद्द करा") }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (isEdit) "Booking Edit करा" else "नवीन Booking") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "मागे")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Kesari,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = customerName,
                onValueChange = { customerName = it },
                label = { Text("Customer Name *") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = mobileNumber,
                onValueChange = { if (it.length <= 10) mobileNumber = it.filter { c -> c.isDigit() } },
                label = { Text("Mobile Number *") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = address,
                onValueChange = { address = it },
                label = { Text("Address") },
                minLines = 2,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = murtiName,
                onValueChange = { murtiName = it },
                label = { Text("Ganpati Murti Name *") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = DateUtils.formatDate(bookingDateMillis),
                onValueChange = {},
                readOnly = true,
                label = { Text("Booking Date") },
                trailingIcon = {
                    TextButton(onClick = { showDatePicker = true }) { Text("बदला") }
                },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = totalPrice,
                onValueChange = { totalPrice = it.filter { c -> c.isDigit() || c == '.' } },
                label = { Text("Total Price (₹) *") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth()
            )
            if (!isEdit) {
                OutlinedTextField(
                    value = advanceAmount,
                    onValueChange = { advanceAmount = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("Advance / Paid Amount (₹)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notes") },
                minLines = 2,
                modifier = Modifier.fillMaxWidth()
            )

            if (error != null) {
                Text(text = error ?: "", color = DangerRed)
            }

            Button(
                onClick = {
                    val price = totalPrice.toDoubleOrNull()
                    when {
                        customerName.isBlank() -> error = "Customer Name आवश्यक आहे"
                        mobileNumber.length != 10 -> error = "योग्य 10 अंकी Mobile Number टाका"
                        murtiName.isBlank() -> error = "Murti Name आवश्यक आहे"
                        price == null || price <= 0.0 -> error = "योग्य Total Price टाका"
                        else -> {
                            error = null
                            if (isEdit && existing != null) {
                                val updated = existing.booking.copy(
                                    customerName = customerName.trim(),
                                    mobileNumber = mobileNumber.trim(),
                                    address = address.trim(),
                                    murtiName = murtiName.trim(),
                                    bookingDate = bookingDateMillis,
                                    totalPrice = price,
                                    notes = notes.trim()
                                )
                                viewModel.updateBooking(updated) { onSaved(updated.id) }
                            } else {
                                val newBooking = Booking(
                                    customerName = customerName.trim(),
                                    mobileNumber = mobileNumber.trim(),
                                    address = address.trim(),
                                    murtiName = murtiName.trim(),
                                    bookingDate = bookingDateMillis,
                                    totalPrice = price,
                                    notes = notes.trim()
                                )
                                val advance = advanceAmount.toDoubleOrNull() ?: 0.0
                                viewModel.addBooking(newBooking, advance) { id -> onSaved(id) }
                            }
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Kesari),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp, bottom = 24.dp)
            ) {
                Text(if (isEdit) "Update करा" else "Booking Save करा")
            }
        }
    }
}
