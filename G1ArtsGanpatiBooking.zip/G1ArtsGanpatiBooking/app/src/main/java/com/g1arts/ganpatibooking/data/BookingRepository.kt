package com.g1arts.ganpatibooking.data

import kotlinx.coroutines.flow.Flow

class BookingRepository(
    private val bookingDao: BookingDao,
    private val paymentDao: PaymentDao
) {
    fun getAllBookings(): Flow<List<BookingWithPayments>> = bookingDao.getAllBookingsWithPayments()

    fun searchBookings(query: String): Flow<List<BookingWithPayments>> = bookingDao.searchBookings(query)

    fun getBooking(id: Long): Flow<BookingWithPayments?> = bookingDao.getBookingWithPayments(id)

    fun getPaymentsForBooking(bookingId: Long): Flow<List<Payment>> = paymentDao.getPaymentsForBooking(bookingId)

    suspend fun addBooking(booking: Booking): Long = bookingDao.insertBooking(booking)

    suspend fun updateBooking(booking: Booking) = bookingDao.updateBooking(booking)

    suspend fun deleteBooking(booking: Booking) = bookingDao.deleteBooking(booking)

    suspend fun addPayment(payment: Payment) = paymentDao.insertPayment(payment)

    suspend fun updateStatus(booking: Booking, newStatus: BookingStatus) {
        bookingDao.updateBooking(booking.copy(status = newStatus.name))
    }
}
