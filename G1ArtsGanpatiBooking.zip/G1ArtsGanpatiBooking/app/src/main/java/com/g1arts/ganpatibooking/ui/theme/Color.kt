package com.g1arts.ganpatibooking.ui.theme

import androidx.compose.ui.graphics.Color

val Kesari = Color(0xFFFF9933)
val KesariDark = Color(0xFFE65100)
val GanpatiRed = Color(0xFFB71C1C)
val Golden = Color(0xFFDAA520)
val GoldenLight = Color(0xFFFFE082)
val CreamBackground = Color(0xFFFFF8E1)
val CardWhite = Color(0xFFFFFFFF)
val TextDark = Color(0xFF3E2723)
val SuccessGreen = Color(0xFF2E7D32)
val WarningAmber = Color(0xFFF9A825)
val InfoBlue = Color(0xFF1565C0)
val DangerRed = Color(0xFFC62828)
