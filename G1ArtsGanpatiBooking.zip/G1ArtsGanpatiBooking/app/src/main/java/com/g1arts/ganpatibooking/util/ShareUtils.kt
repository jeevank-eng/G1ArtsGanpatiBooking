package com.g1arts.ganpatibooking.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

object ShareUtils {

    /** Opens the user's default SMS app with the message pre-filled, ready to send. */
    fun sendSms(context: Context, phoneNumber: String, message: String) {
        try {
            val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$phoneNumber")).apply {
                putExtra("sms_body", message)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "SMS App उघडता आले नाही", Toast.LENGTH_SHORT).show()
        }
    }

    /** Opens WhatsApp (or browser fallback) with the message pre-filled for the given number. */
    fun sendWhatsApp(context: Context, phoneNumber: String, message: String) {
        try {
            val cleaned = phoneNumber.filter { it.isDigit() }
            val fullNumber = if (cleaned.length == 10) "91$cleaned" else cleaned
            val uri = Uri.parse("https://wa.me/$fullNumber?text=${Uri.encode(message)}")
            val intent = Intent(Intent.ACTION_VIEW, uri)
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "WhatsApp उघडता आले नाही", Toast.LENGTH_SHORT).show()
        }
    }
}
