package com.g1arts.ganpatibooking.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.g1arts.ganpatibooking.data.BookingStatus
import com.g1arts.ganpatibooking.ui.components.ConfirmDialog
import com.g1arts.ganpatibooking.ui.components.StatusChip
import com.g1arts.ganpatibooking.ui.theme.DangerRed
import com.g1arts.ganpatibooking.ui.theme.Kesari
import com.g1arts.ganpatibooking.ui.theme.SuccessGreen
import com.g1arts.ganpatibooking.util.DateUtils
import com.g1arts.ganpatibooking.util.MessageTemplates
import com.g1arts.ganpatibooking.util.ShareUtils
import com.g1arts.ganpatibooking.viewmodel.BookingViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookingDetailScreen(
    viewModel: BookingViewModel,
    bookingId: Long,
    onBack: () -> Unit,
    onEdit: (Long) -> Unit,
    onDeleted: () -> Unit
) {
    val context = LocalContext.current
    val itemFlow = remember(bookingId) { viewModel.getBookingFlow(bookingId) }
    val item by itemFlow.collectAsState(initial = null)

    var showDeleteConfirm by remember { mutableStateOf(false) }
    var showPaymentDialog by remember { mutableStateOf(false) }
    var showStatusMenu by remember { mutableStateOf(false) }

    if (item == null) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Booking Details") },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.Filled.ArrowBack, contentDescription = "मागे")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Kesari, titleContentColor = Color.White)
                )
            }
        ) { padding ->
            Column(modifier = Modifier.padding(padding).padding(16.dp)) {
                Text("लोड होत आहे...")
            }
        }
        return
    }

    val data = item!!
    val booking = data.booking
    val status = BookingStatus.fromName(booking.status)

    if (showDeleteConfirm) {
        ConfirmDialog(
            title = "Booking Delete करा",
            message = "ही Booking कायमची Delete करायची आहे का?",
            onConfirm = {
                showDeleteConfirm = false
                viewModel.deleteBooking(booking) { onDeleted() }
            },
            onDismiss = { showDeleteConfirm = false }
        )
    }

    if (showPaymentDialog) {
        AddPaymentDialog(
            onDismiss = { showPaymentDialog = false },
            onAdd = { amount, note ->
                viewModel.addPayment(booking.id, amount, note)
                showPaymentDialog = false
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Booking Details") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "मागे")
                    }
                },
                actions = {
                    IconButton(onClick = { onEdit(booking.id) }) {
                        Icon(Icons.Filled.Edit, contentDescription = "Edit")
                    }
                    IconButton(onClick = { showDeleteConfirm = true }) {
                        Icon(Icons.Filled.Delete, contentDescription = "Delete")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Kesari,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Card(shape = RoundedCornerShape(16.dp), elevation = CardDefaults.cardElevation(3.dp)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(booking.customerName, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        Box {
                            Box(modifier = Modifier.clickable { showStatusMenu = true }) {
                                StatusChip(status)
                            }
                            DropdownMenu(expanded = showStatusMenu, onDismissRequest = { showStatusMenu = false }) {
                                BookingStatus.values().forEach { s ->
                                    DropdownMenuItem(
                                        text = { Text(s.marathiLabel) },
                                        onClick = {
                                            viewModel.updateStatus(booking, s)
                                            showStatusMenu = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                    DetailRow("Mobile", booking.mobileNumber)
                    DetailRow("Address", booking.address.ifBlank { "-" })
                    DetailRow("Murti", booking.murtiName)
                    DetailRow("Booking Date", DateUtils.formatDate(booking.bookingDate))
                    DetailRow("Total Price", DateUtils.formatPrice(booking.totalPrice))
                    DetailRow("Paid Amount", DateUtils.formatPrice(data.paidAmount))
                    DetailRow("Pending Amount", DateUtils.formatPrice(data.pendingAmount))
                    if (booking.notes.isNotBlank()) {
                        DetailRow("Notes", booking.notes)
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = {
                        val msg = MessageTemplates.buildSmsMessage(booking, data.paidAmount, data.pendingAmount)
                        ShareUtils.sendSms(context, booking.mobileNumber, msg)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Kesari),
                    modifier = Modifier.weight(1f)
                ) { Text("SMS पाठवा") }

                Button(
                    onClick = {
                        val msg = MessageTemplates.buildWhatsAppMessage(
                            booking, data.paidAmount, data.pendingAmount, status.marathiLabel
                        )
                        ShareUtils.sendWhatsApp(context, booking.mobileNumber, msg)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                    modifier = Modifier.weight(1f)
                ) { Text("WhatsApp पाठवा") }
            }

            OutlinedButton(
                onClick = { showPaymentDialog = true },
                modifier = Modifier.fillMaxWidth()
            ) { Text("+ नवीन Payment Add करा") }

            Text("Payment History", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            if (data.payments.isEmpty()) {
                Text("अजून कोणताही Payment नोंदवलेला नाही")
            } else {
                data.payments.sortedByDescending { it.date }.forEach { payment ->
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        elevation = CardDefaults.cardElevation(1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(DateUtils.formatDateTime(payment.date), fontSize = 12.sp)
                                if (payment.note.isNotBlank()) {
                                    Text(payment.note, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            Text(DateUtils.formatPrice(payment.amount), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
        Text(value, fontWeight = FontWeight.Medium, fontSize = 14.sp)
    }
}

@Composable
private fun AddPaymentDialog(
    onDismiss: () -> Unit,
    onAdd: (Double, String) -> Unit
) {
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("नवीन Payment Add करा") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("Amount (₹)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Note (उदा. 2nd Payment)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (error != null) {
                    Text(error ?: "", color = DangerRed)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val amt = amount.toDoubleOrNull()
                if (amt == null || amt <= 0.0) {
                    error = "योग्य Amount टाका"
                } else {
                    onAdd(amt, note.trim())
                }
            }) { Text("Add करा") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("रद्द करा") }
        }
    )
}
