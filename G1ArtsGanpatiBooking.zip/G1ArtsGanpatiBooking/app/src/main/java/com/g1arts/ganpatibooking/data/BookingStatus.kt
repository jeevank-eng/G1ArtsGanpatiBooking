package com.g1arts.ganpatibooking.data

enum class BookingStatus(val marathiLabel: String) {
    PENDING("प्रलंबित"),
    CONFIRMED("निश्चित"),
    COMPLETED("पूर्ण"),
    CANCELLED("रद्द");

    companion object {
        fun fromName(name: String): BookingStatus =
            values().find { it.name == name } ?: PENDING
    }
}
