package com.g1arts.ganpatibooking

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.remember
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.g1arts.ganpatibooking.ui.navigation.Routes
import com.g1arts.ganpatibooking.ui.screens.AddEditBookingScreen
import com.g1arts.ganpatibooking.ui.screens.AdminLoginScreen
import com.g1arts.ganpatibooking.ui.screens.BookingDetailScreen
import com.g1arts.ganpatibooking.ui.screens.BookingListScreen
import com.g1arts.ganpatibooking.ui.screens.DashboardScreen
import com.g1arts.ganpatibooking.ui.screens.SplashScreen
import com.g1arts.ganpatibooking.ui.theme.G1ArtsGanpatiBookingTheme
import com.g1arts.ganpatibooking.util.AdminAuthManager
import com.g1arts.ganpatibooking.viewmodel.BookingViewModel
import com.g1arts.ganpatibooking.viewmodel.BookingViewModelFactory

class MainActivity : ComponentActivity() {

    private val viewModel: BookingViewModel by viewModels { BookingViewModelFactory(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            G1ArtsGanpatiBookingTheme {
                val navController = rememberNavController()
                val authManager = remember { AdminAuthManager(this) }

                NavHost(navController = navController, startDestination = Routes.SPLASH) {

                    composable(Routes.SPLASH) {
                        SplashScreen(onFinished = {
                            navController.navigate(Routes.LOGIN) {
                                popUpTo(Routes.SPLASH) { inclusive = true }
                            }
                        })
                    }

                    composable(Routes.LOGIN) {
                        AdminLoginScreen(
                            authManager = authManager,
                            onLoginSuccess = {
                                navController.navigate(Routes.DASHBOARD) {
                                    popUpTo(Routes.LOGIN) { inclusive = true }
                                }
                            }
                        )
                    }

                    composable(Routes.DASHBOARD) {
                        DashboardScreen(
                            viewModel = viewModel,
                            onAddBooking = { navController.navigate(Routes.ADD_BOOKING) },
                            onOpenList = { navController.navigate(Routes.BOOKING_LIST) },
                            onOpenSearch = { navController.navigate(Routes.BOOKING_SEARCH) },
                            onOpenBooking = { id -> navController.navigate(Routes.bookingDetail(id)) }
                        )
                    }

                    composable(Routes.BOOKING_LIST) {
                        BookingListScreen(
                            viewModel = viewModel,
                            focusSearch = false,
                            onBack = { navController.popBackStack() },
                            onOpenBooking = { id -> navController.navigate(Routes.bookingDetail(id)) }
                        )
                    }

                    composable(Routes.BOOKING_SEARCH) {
                        BookingListScreen(
                            viewModel = viewModel,
                            focusSearch = true,
                            onBack = { navController.popBackStack() },
                            onOpenBooking = { id -> navController.navigate(Routes.bookingDetail(id)) }
                        )
                    }

                    composable(Routes.ADD_BOOKING) {
                        AddEditBookingScreen(
                            viewModel = viewModel,
                            bookingId = null,
                            onBack = { navController.popBackStack() },
                            onSaved = { id ->
                                navController.popBackStack()
                                navController.navigate(Routes.bookingDetail(id))
                            }
                        )
                    }

                    composable(
                        route = Routes.EDIT_BOOKING,
                        arguments = listOf(navArgument("bookingId") { type = NavType.LongType })
                    ) { backStackEntry ->
                        val id = backStackEntry.arguments?.getLong("bookingId") ?: 0L
                        AddEditBookingScreen(
                            viewModel = viewModel,
                            bookingId = id,
                            onBack = { navController.popBackStack() },
                            onSaved = { savedId ->
                                navController.popBackStack()
                                navController.navigate(Routes.bookingDetail(savedId)) {
                                    launchSingleTop = true
                                }
                            }
                        )
                    }

                    composable(
                        route = Routes.BOOKING_DETAIL,
                        arguments = listOf(navArgument("bookingId") { type = NavType.LongType })
                    ) { backStackEntry ->
                        val id = backStackEntry.arguments?.getLong("bookingId") ?: 0L
                        BookingDetailScreen(
                            viewModel = viewModel,
                            bookingId = id,
                            onBack = { navController.popBackStack() },
                            onEdit = { editId -> navController.navigate(Routes.editBooking(editId)) },
                            onDeleted = { navController.popBackStack() }
                        )
                    }
                }
            }
        }
    }
}
