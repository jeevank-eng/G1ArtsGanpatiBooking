package com.g1arts.ganpatibooking.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.g1arts.ganpatibooking.data.Booking
import com.g1arts.ganpatibooking.data.BookingRepository
import com.g1arts.ganpatibooking.data.BookingStatus
import com.g1arts.ganpatibooking.data.BookingWithPayments
import com.g1arts.ganpatibooking.data.Payment
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class DashboardStats(
    val totalBookings: Int = 0,
    val pending: Int = 0,
    val confirmed: Int = 0,
    val completed: Int = 0,
    val cancelled: Int = 0,
    val totalAmount: Double = 0.0,
    val totalPaid: Double = 0.0,
    val totalPending: Double = 0.0
)

class BookingViewModel(private val repository: BookingRepository) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    @OptIn(ExperimentalCoroutinesApi::class)
    val bookings: StateFlow<List<BookingWithPayments>> = _searchQuery
        .debounce(200)
        .flatMapLatest { query ->
            if (query.isBlank()) repository.getAllBookings()
            else repository.searchBookings(query.trim())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dashboardStats: StateFlow<DashboardStats> = repository.getAllBookings()
        .map { list ->
            DashboardStats(
                totalBookings = list.size,
                pending = list.count { it.booking.status == BookingStatus.PENDING.name },
                confirmed = list.count { it.booking.status == BookingStatus.CONFIRMED.name },
                completed = list.count { it.booking.status == BookingStatus.COMPLETED.name },
                cancelled = list.count { it.booking.status == BookingStatus.CANCELLED.name },
                totalAmount = list.sumOf { it.booking.totalPrice },
                totalPaid = list.sumOf { it.paidAmount },
                totalPending = list.sumOf { it.pendingAmount }
            )
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardStats())

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun getBookingFlow(id: Long) = repository.getBooking(id)

    fun addBooking(booking: Booking, initialAdvance: Double, onDone: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val id = repository.addBooking(booking)
            if (initialAdvance > 0.0) {
                repository.addPayment(
                    Payment(bookingId = id, amount = initialAdvance, note = "Advance")
                )
            }
            onDone(id)
        }
    }

    fun updateBooking(booking: Booking, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repository.updateBooking(booking)
            onDone()
        }
    }

    fun deleteBooking(booking: Booking, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repository.deleteBooking(booking)
            onDone()
        }
    }

    fun addPayment(bookingId: Long, amount: Double, note: String, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repository.addPayment(Payment(bookingId = bookingId, amount = amount, note = note))
            onDone()
        }
    }

    fun updateStatus(booking: Booking, status: BookingStatus) {
        viewModelScope.launch {
            repository.updateStatus(booking, status)
        }
    }
}
