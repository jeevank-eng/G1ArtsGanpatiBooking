package com.g1arts.ganpatibooking.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.g1arts.ganpatibooking.ui.components.BookingListItem
import com.g1arts.ganpatibooking.ui.components.SummaryCard
import com.g1arts.ganpatibooking.ui.theme.DangerRed
import com.g1arts.ganpatibooking.ui.theme.InfoBlue
import com.g1arts.ganpatibooking.ui.theme.Kesari
import com.g1arts.ganpatibooking.ui.theme.SuccessGreen
import com.g1arts.ganpatibooking.ui.theme.WarningAmber
import com.g1arts.ganpatibooking.util.DateUtils
import com.g1arts.ganpatibooking.viewmodel.BookingViewModel

private data class StatCard(val title: String, val value: String, val color: Color)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: BookingViewModel,
    onAddBooking: () -> Unit,
    onOpenList: () -> Unit,
    onOpenSearch: () -> Unit,
    onOpenBooking: (Long) -> Unit
) {
    val stats by viewModel.dashboardStats.collectAsState()
    val bookings by viewModel.bookings.collectAsState()
    val recent = bookings.take(5)

    val statCards = listOf(
        StatCard("Total Bookings", "${stats.totalBookings}", Kesari),
        StatCard("Pending", "${stats.pending}", WarningAmber),
        StatCard("Confirmed", "${stats.confirmed}", InfoBlue),
        StatCard("Completed", "${stats.completed}", SuccessGreen),
        StatCard("Cancelled", "${stats.cancelled}", DangerRed),
        StatCard("Total Amount", DateUtils.formatPrice(stats.totalAmount), Kesari),
        StatCard("Total Paid", DateUtils.formatPrice(stats.totalPaid), SuccessGreen),
        StatCard("Total Pending", DateUtils.formatPrice(stats.totalPending), DangerRed)
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("G-1 Arts", fontWeight = FontWeight.Bold)
                        Text("Ganpati Booking Dashboard", fontSize = 12.sp)
                    }
                },
                actions = {
                    IconButton(onClick = onOpenSearch) {
                        Icon(Icons.Filled.Search, contentDescription = "Search")
                    }
                    IconButton(onClick = onOpenList) {
                        Icon(Icons.Filled.List, contentDescription = "All Bookings")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Kesari,
                    titleContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onAddBooking, containerColor = Kesari, contentColor = Color.White) {
                Icon(Icons.Filled.Add, contentDescription = "नवीन Booking")
            }
        }
    ) { padding ->
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(padding),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    statCards.chunked(2).forEach { rowItems ->
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            rowItems.forEach { card ->
                                SummaryCard(
                                    title = card.title,
                                    value = card.value,
                                    accentColor = card.color,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            if (rowItems.size == 1) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    text = "अलीकडील Bookings",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
                )
            }

            if (recent.isEmpty()) {
                item {
                    Text(
                        text = "अजून कोणतीही Booking नाही. + बटण दाबून नवीन Booking तयार करा.",
                        modifier = Modifier.padding(vertical = 20.dp)
                    )
                }
            } else {
                items(recent) { item ->
                    BookingListItem(item = item, onClick = { onOpenBooking(item.booking.id) })
                }
            }
        }
    }
}
