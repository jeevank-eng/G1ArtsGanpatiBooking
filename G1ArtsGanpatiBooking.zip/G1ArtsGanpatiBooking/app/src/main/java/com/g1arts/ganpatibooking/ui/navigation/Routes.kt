package com.g1arts.ganpatibooking.ui.navigation

object Routes {
    const val SPLASH = "splash"
    const val LOGIN = "login"
    const val DASHBOARD = "dashboard"
    const val BOOKING_LIST = "booking_list"
    const val BOOKING_SEARCH = "booking_search"
    const val ADD_BOOKING = "add_booking"
    const val EDIT_BOOKING = "edit_booking/{bookingId}"
    const val BOOKING_DETAIL = "booking_detail/{bookingId}"

    fun editBooking(bookingId: Long) = "edit_booking/$bookingId"
    fun bookingDetail(bookingId: Long) = "booking_detail/$bookingId"
}
