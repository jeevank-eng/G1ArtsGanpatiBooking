package com.g1arts.ganpatibooking.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "bookings")
data class Booking(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerName: String,
    val mobileNumber: String,
    val address: String,
    val murtiName: String,
    val bookingDate: Long,
    val totalPrice: Double,
    val status: String = BookingStatus.PENDING.name,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
