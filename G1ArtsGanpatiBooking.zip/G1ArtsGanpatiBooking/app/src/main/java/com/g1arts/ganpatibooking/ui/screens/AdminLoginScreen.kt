package com.g1arts.ganpatibooking.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.g1arts.ganpatibooking.ui.theme.CreamBackground
import com.g1arts.ganpatibooking.ui.theme.DangerRed
import com.g1arts.ganpatibooking.ui.theme.Kesari
import com.g1arts.ganpatibooking.util.AdminAuthManager

@Composable
fun AdminLoginScreen(
    authManager: AdminAuthManager,
    onLoginSuccess: () -> Unit
) {
    val isPinSet = remember { authManager.isPinSet() }

    if (isPinSet) {
        LoginContent(authManager = authManager, onLoginSuccess = onLoginSuccess)
    } else {
        SetupPinContent(authManager = authManager, onSetupDone = onLoginSuccess)
    }
}

@Composable
private fun LoginContent(authManager: AdminAuthManager, onLoginSuccess: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CreamBackground)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .background(Kesari, CircleShape)
                    .padding(20.dp)
            ) {
                Text(text = "\uD83D\uDD10", fontSize = 32.sp)
            }
            Text(
                text = "Admin Login",
                fontWeight = FontWeight.Bold,
                fontSize = 22.sp,
                modifier = Modifier.padding(top = 16.dp, bottom = 4.dp)
            )
            Text(text = "कृपया आपला PIN टाका", fontSize = 14.sp)

            OutlinedTextField(
                value = pin,
                onValueChange = { if (it.length <= 6) pin = it; error = null },
                label = { Text("PIN") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 20.dp)
            )

            if (error != null) {
                Text(text = error ?: "", color = DangerRed, modifier = Modifier.padding(top = 8.dp))
            }

            Button(
                onClick = {
                    if (authManager.verifyPin(pin)) {
                        onLoginSuccess()
                    } else {
                        error = "चुकीचा PIN, पुन्हा प्रयत्न करा"
                        pin = ""
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 20.dp),
                colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = Kesari)
            ) {
                Text("Login")
            }
        }
    }
}

@Composable
private fun SetupPinContent(authManager: AdminAuthManager, onSetupDone: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CreamBackground)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "Admin PIN सेट करा",
                fontWeight = FontWeight.Bold,
                fontSize = 22.sp
            )
            Text(
                text = "ही PIN फक्त तुम्हालाच माहित असेल, booking डिलीट/बदल करण्यासाठी लागेल",
                fontSize = 13.sp,
                modifier = Modifier.padding(top = 6.dp, bottom = 16.dp)
            )

            OutlinedTextField(
                value = pin,
                onValueChange = { if (it.length <= 6) pin = it; error = null },
                label = { Text("नवीन PIN (4-6 अंक)") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = confirmPin,
                onValueChange = { if (it.length <= 6) confirmPin = it; error = null },
                label = { Text("PIN पुन्हा टाका") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp)
            )

            if (error != null) {
                Text(text = error ?: "", color = DangerRed, modifier = Modifier.padding(top = 8.dp))
            }

            Button(
                onClick = {
                    when {
                        pin.length < 4 -> error = "PIN किमान 4 अंकी असावा"
                        pin != confirmPin -> error = "PIN जुळत नाही"
                        else -> {
                            authManager.setPin(pin)
                            onSetupDone()
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 20.dp),
                colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = Kesari)
            ) {
                Text("PIN सेव्ह करा")
            }
        }
    }
}
