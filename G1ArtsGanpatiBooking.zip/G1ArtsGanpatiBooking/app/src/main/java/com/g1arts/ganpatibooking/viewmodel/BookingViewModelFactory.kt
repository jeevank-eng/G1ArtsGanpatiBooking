package com.g1arts.ganpatibooking.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.g1arts.ganpatibooking.data.AppDatabase
import com.g1arts.ganpatibooking.data.BookingRepository

class BookingViewModelFactory(context: Context) : ViewModelProvider.Factory {
    private val repository: BookingRepository

    init {
        val db = AppDatabase.getInstance(context)
        repository = BookingRepository(db.bookingDao(), db.paymentDao())
    }

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(BookingViewModel::class.java)) {
            return BookingViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
