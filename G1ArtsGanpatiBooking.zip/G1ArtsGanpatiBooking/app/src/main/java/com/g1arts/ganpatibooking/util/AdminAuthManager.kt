package com.g1arts.ganpatibooking.util

import android.content.Context
import android.content.SharedPreferences
import java.security.MessageDigest

/**
 * Simple PIN based protection for the Admin section.
 * The PIN is stored only as a SHA-256 hash in private SharedPreferences,
 * never in plain text.
 */
class AdminAuthManager(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun isPinSet(): Boolean = prefs.contains(KEY_PIN_HASH)

    fun setPin(pin: String) {
        prefs.edit().putString(KEY_PIN_HASH, hash(pin)).apply()
    }

    fun verifyPin(pin: String): Boolean {
        val stored = prefs.getString(KEY_PIN_HASH, null) ?: return false
        return stored == hash(pin)
    }

    private fun hash(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    companion object {
        private const val PREFS_NAME = "g1arts_admin_prefs"
        private const val KEY_PIN_HASH = "pin_hash"
    }
}
