# G-1 Arts Ganpati Booking - ProGuard rules
# Add project specific ProGuard rules here.
-keep class com.g1arts.ganpatibooking.data.** { *; }
